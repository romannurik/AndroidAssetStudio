# No Maintenance Intended

Tell people your code is open source, but not actively maintained.

Add a shiny badge like this to your project:

[![No Maintenance Intended](http://unmaintained.tech/badge.svg)](http://unmaintained.tech/)
